from django.apps import AppConfig


class MessagingAppConfig(AppConfig):
    name = 'ticketing_app'
