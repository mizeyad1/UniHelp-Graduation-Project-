const FireFly = () => {
  return (
    <div>
      <div className='firefly'></div>
      <div className='firefly'></div>
      <div className='firefly'></div>
      <div className='firefly'></div>
      <div className='firefly'></div>
      <div className='firefly'></div>
      <div className='firefly'></div>
      <div className='firefly'></div>
      <div className='firefly'></div>
      <div className='firefly'></div>
      <div className='firefly'></div>
      <div className='firefly'></div>
      <div className='firefly'></div>
      <div className='firefly'></div>
      <div className='firefly'></div>
    </div>
  );
};

export default FireFly;
