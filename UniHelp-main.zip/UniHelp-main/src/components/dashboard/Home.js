import React, { Fragment } from "react";

const Home = () => {
  return (
    <Fragment>
      <div className='page-header'>
        <div className='container-fluid'>
          <h2 className='h5 no-margin-bottom'>Home</h2>
        </div>
      </div>
      <section></section>
    </Fragment>
  );
};

export default Home;
